var p1Button=document.querySelector("#p1");
var p2Button=document.querySelector("#p2");
var p1display=document.querySelector("#p1display");
var p2display=document.querySelector("#p2display")
var reset=document.querySelector("#p3");
var winningcount=document.querySelector("input");
var dno=document.querySelector("h3 span");
var playingto=5;

var p1count=0;
var p2count=0;
var gameover=false;
p1Button.addEventListener("click",function(){
if(!gameover){
	p1count++;

	if(p1count===playingto){
		p1display.classList.add("winner");
		gameover=true;
	}
	p1display.textContent=p1count;
}


});
p2Button.addEventListener("click",function(){
if(!gameover){
	p2count++;

	if(p2count===playingto){
		p2display.classList.add("winner");
		gameover=true;
	}
	p2display.textContent=p2count;
}});


reset.addEventListener("click", function(){
rset();
});

function rset(){
p1count=0;
p2count=0;
p1display.textContent=0;
p2display.textContent=0;
p1display.classList.remove("winner");
p2display.classList.remove("winner");
gameover=false;
}

winningcount.addEventListener("change",function(){
dno.textContent=this.value;
playingto=Number(this.value);
rset();
})









